<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="Author" content="Maciej Grembski">
    <link rel="stylesheet" href="style.css">
    <title>Jamal's Weed</title>
    <?php
        error_reporting(1);
    ?>
</head>

<body>
    <div id="Page">
        <div id="Banner">
            <div id="Container" style="border:groove; border-color:greenyellow;">
                <div id="Head">
                    <div id="Head_L">
                        <div id="Leaf_top">
                            <img src="assets/rastaman.png">
                                <div id="Leaf_bot">
    </div>
                                    <div id="Head_R">
                                        <div id="Logo">
                                            <video  loop autoplay="autoplay" muted controls="hidden" id="vid" width="600px" height="162px">
                                                <source src="assets/Jamal's Weed.mp4" type="video/mp4">
                                                <source src="assets/Jamal's Weed.mp4" type="video/ogg">                
                                            </video>
                                        </div>
                                    </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
